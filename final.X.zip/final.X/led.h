#ifndef SO_H_
#define SO_H_

	void ligaLed (char num , float tempo);
	void desligaLed (char num , float tempo);

#endif
