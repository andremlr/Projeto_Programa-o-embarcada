#include "led.h"
#include "io.h"
 
void ligaLed(char num , float tempo){
    
    volatile unsigned char j, k;

        //delay de 1 ms

        for (j = 0; j < 41; j++) {

            for (k = 0; k < 3; k++);
        }
        digitalWrite(LED_RED_PIN, HIGH);//liga led
}

void desligaLed(char num , float tempo){
    
    volatile unsigned char j, k;

        //delay de 1 ms

        for (j = 0; j < 41; j++) {

            for (k = 0; k < 3; k++);

        }
    digitalWrite(LED_RED_PIN, LOW);// Apaga LED
}
