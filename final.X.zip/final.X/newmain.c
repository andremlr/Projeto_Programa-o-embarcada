#include "config.h" 
#include "bits.h" 
#include "lcd.h" 
#include "keypad.h"
#include <pic18f4520.h>
#include "ssd.h"

#define L0 0x80 // linha 0, coluna 0
#define L1 0xC0 // linha 1, coluna 0
#define CLR 0x01
#define ON 0x0F

void lcdPosition(unsigned char l, unsigned char c) {
    if (l == 0)
        lcdCommand(L0 + c);
    if (l == 1)
        lcdCommand(L1 + c);
}

void main(void) {
    unsigned int tecla = 16;
    unsigned long int cont = 10;
    int diaPt1=1;
    int diaPt2=0;
    int mesPt1=1;
    int mesPt2=0;
    int anoPt1=1;
    int anoPt2=2;
    int anoPt3=0;
    int anoPt4=2;
    lcdInit();// inicializa
    ssdInit();
    kpInit();
    //int cont=0;
    int j,i;
    TRISD=0x00;
    for (;;) {
        if(mesPt1%2==0){
            PORTD = 0b00000010;
        }
        else{
            PORTD = 0b00000011;
        }
        lcdCommand(L0);
        kpDebounce();
        if (kpRead() != tecla) {
            tecla = kpRead();//ler tecla
            if (bitTst(tecla, 3)) { // - hora
                cont -= 360000;
            }
            if (bitTst(tecla, 7)) { // + hora
                cont += 360000;
            }
            if (bitTst(tecla, 2)) { // - min
                cont -= 6000;
            }
            if (bitTst(tecla, 6)) { // + min
                cont += 6000;
            }
             if (bitTst(tecla, 1)) { // - seg
                cont -= 100;
            }
             if (bitTst(tecla, 5)) { // + seg
                cont += 100;
            }
            if(bitTst(tecla,4)){//+dia
                diaPt1++;
            }
            if(bitTst(tecla,8)){//+mes
                mesPt1++;
            }
            if(bitTst(tecla,9)){//-dia
                diaPt1--;
            }
            if(bitTst(tecla,0)){//-mes
                mesPt1--;
            }
        }
        cont++;
        if((diaPt1==0)&&diaPt2==0){//para atualizar o dia corretamente
            mesPt1--;
            if((mesPt1==0)&&(mesPt2==0)){
                mesPt1=2;
                mesPt2=1;
                anoPt1--;
                if(anoPt1==-1){
                    anoPt1=9;
                    anoPt2--;
                    if(anoPt2==-1){
                        anoPt2=9;
                        anoPt3--;
                        if(anoPt3==-1){
                            anoPt3=9;
                            anoPt4--;
                        }
                        if(anoPt4==-1){
                            anoPt4=9;
                        }
                    }
                }
            }
            if((mesPt2==0)&&(mesPt1==2)){
                diaPt1=8;
                diaPt2=2;
            }
            else{
                if(((mesPt2==0)&&(mesPt1==4)||(mesPt1==6)||(mesPt1==9))||((mesPt2==1)&&(mesPt1==1))){
                    diaPt1=0;
                    diaPt2=3;
                }
                else{
                    diaPt1=1;
                    diaPt2=3;
                }
            }
        }
        else{
            if(diaPt1==-1){
                diaPt1=9;
                diaPt2--;
            }
        }
        if((mesPt1==0)&&(mesPt2==0)){//para atualizar mes corretamente
            mesPt1=9;
            mesPt2--;
            if(mesPt2==-1){
                mesPt1=2;
                mesPt2=1;
                anoPt1--;
                if(anoPt1==-1){
                    anoPt1=9;
                    anoPt2--;
                    if(anoPt2==-1){
                        anoPt2=9;
                        anoPt3--;
                        if(anoPt3==-1){
                            anoPt3=9;
                            anoPt4--;
                        }
                        if(anoPt4==-1){
                            anoPt4=9;
                        }
                    }
                }
            }
        }
        else{
            if(mesPt1==-1){
                mesPt1=9;
                mesPt2=0;
            }
        }
        if(diaPt1==10){
            diaPt1=0;
            diaPt2++;
        }
        if(((mesPt2==0)&&(mesPt1==4)||(mesPt1==6)||(mesPt1==9))||((mesPt2==1)&&(mesPt1==1))){
            if((diaPt2==3)&&(diaPt1==1)){
                diaPt2=0;
                diaPt1=1;
                mesPt1++;
            }
            if((mesPt1==10)){
                mesPt2++;
                mesPt1=0;
            }
        }
        else{
            if((mesPt2==0)&&(mesPt1==2)){
                if((diaPt2==2)&&(diaPt1==9)){
                    diaPt2=0;
                    diaPt1=1;
                    mesPt1++;
                }
            }
            else{
                if((diaPt2==3)&&(diaPt1==2)){
                    diaPt2=0;
                    diaPt1=1;
                    mesPt1++;
                }
            }
        }
        if(mesPt1==10){
            mesPt1=0;
            mesPt2++;
        }
        if((mesPt1==3)&&(mesPt2==1)){
            mesPt1=1;
            mesPt2=0;
            anoPt1++;
        }
        if(anoPt1==10){
            anoPt2++;
            anoPt1=0;
        }
        if(anoPt2==10){
            anoPt2=0;
            anoPt3++;
        }
        if(anoPt3==10){
            anoPt3=0;
            anoPt4++;
        }
        if(anoPt4==10){
            anoPt4=0;
            anoPt3=0;
            anoPt2=0;
            anoPt1=0;
        }
        lcdChar((((cont / 360000) % 24) / 10) + 48);//para printar na tela hora
        lcdChar((((cont / 360000) % 24) % 10) + 48);//printar resto da hora
        lcdChar(':');
        lcdChar((cont / 60000) % 6 + 48);//printar min
        lcdChar((cont / 6000) % 10 + 48);//printar resto dos min
        lcdChar(':');
        lcdChar((cont / 1000) % 6 + 48);//printar seg
        lcdChar((cont / 100) % 10 + 48);//printar resto seg
        lcdCommand(0xC0);
        lcdChar((diaPt2/1)+48);
        lcdChar((diaPt1/1)+48);
        lcdChar(47);
        lcdChar((mesPt2/1)+48);
        lcdChar((mesPt1/1)+48);
        lcdChar(47);
        lcdChar((anoPt4/1)+48);
        lcdChar((anoPt3/1)+48);
        lcdChar((anoPt2/1)+48);
        lcdChar((anoPt1/1)+48);
        
    }
    
       
    
}
